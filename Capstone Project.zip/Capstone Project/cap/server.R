library(lubridate)
library(dplyr)
library(ggplot2)
library(shinydashboard)
library(varhandle)
library(shiny)
library(tidyr)
library(reshape)

source("Helpers/cleaner.R")
source("Helpers/chart.R")


# Define server logic required to draw a histogram
shinyServer(function(input, output) {



  output$toppub <- renderInfoBox({
    infoBox(
      title = "Most Release", 
      value = toppub[match(max(toppub$n),toppub$n),"Publisher"],width=8,
      icon=icon("cubes"), 
      subtitle = "Top publisher by games title launch")
  })
  

  output$avgsales <-renderInfoBox({
    infoBox(
      title = "Average Sales per Publisher", 
      value = round(avgsales$avgs,digits=2),"orange", width=8,
      icon=icon("shopping-cart"), 
      subtitle = "Annual video game sales until 2016")
  })
  
  
  output$topgenre<-renderInfoBox({
    infoBox(
      title = "Top Genre", 
      value = data.frame(tgenre[1,1],": ",round(tgenre[1,2],2)),"green", width=6,
      icon=icon("bomb"), 
      subtitle = "Genre with highest rating")
  }) 
  
  output$topplatform<-renderInfoBox({
    infoBox(
      title = "Top Platform", 
      value = data.frame(tplatform[1,1],": ",round(tplatform[1,2],2)),"purple", width=6,
      icon=icon("building"), 
      subtitle = "Platform with highest rating")
  }) 
  
  output$toppublisher<-renderInfoBox({
    infoBox(
      title = "Top Publisher", 
      value = data.frame(tpublish[1,1],": ",round(tpublish[1,2],2)),"red", width=6,
      icon=icon("bug"), 
      subtitle = "Publisher with highest rating")
  }) 
  
  
  output$plot1 <- renderPlot({
    if(input$input.tot==TRUE){
      vgame%>%
        filter(Year_of_Release !="N/A")%>%
        select(Year_of_Release, NA_Sales,EU_Sales,JP_Sales,Other_Sales)%>%
        melt(id.vars=c("Year_of_Release"))%>%        
        ggplot(aes(x=Year_of_Release,y=value))+
        geom_col(aes(fill=variable),position="stack")+
        labs(subtitle="Data is collected from 1980-2017",caption="source: Kaggle.com",x= "Year of Release",y="Sales (USD)")+
        scale_fill_manual(values=c("cadetblue2","cadetblue3","cadetblue4","deepskyblue4"))
      
    }  else{
      vgame%>%
      filter(Publisher == input$input.pub&Year_of_Release !="N/A")%>%
      select(Year_of_Release, NA_Sales,EU_Sales,JP_Sales,Other_Sales)%>%
      melt(id.vars=c("Year_of_Release"))%>%        
      ggplot(aes(x=Year_of_Release,y=value))+
      geom_col(aes(fill=variable),position="stack")+
      labs(subtitle=paste("Data is collected from 1980-2017 for",input$input.pub),caption="source: Kaggle.com",x= "Year of Release",y="Sales (USD)")+
      scale_fill_manual(values=c("cadetblue2","cadetblue3","cadetblue4","deepskyblue4"))
    }
  })
  
  
  output$plot2 <- renderPlot({
    if(input$input.reg =="North America"){
      vna} else if(input$input.reg =="Europe"){
        veu} else if (input$input.reg =="Japan"){
          vjp} else if (input$input.reg =="Other"){
            vot } else if (input$input.reg =="Global"){
              vgl}
    })
  

  output$table1<-renderTable({
    vsearch1<-vgame%>%
      filter(Publisher == input$ïnput.sch)%>%
      arrange(desc(Year_of_Release))%>%
      select(c(-5,-12,-14,-15))
    
    vsearch2<-vgame%>%
      filter(Publisher == input$ïnput.sch)%>%
      arrange(desc(Genre))%>%
      select(c(-5,-12,-14,-15))
    
    vsearch3<-vgame%>%
      filter(Publisher == input$ïnput.sch)%>%
      arrange(desc(Critic_Score))%>%
      select(c(-5,-12,-14,-15))

    if(input$ïnput.arr =="Year"){
      vsearch1
    } else if(input$ïnput.arr =="Genre"){
        vsearch2
      } else {
        vsearch3
      }
      
    })
})

