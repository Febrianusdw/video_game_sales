
library(shiny)
library(shinydashboard)

source("Helpers/cleaner.R")
source("Helpers/chart.R")

# Define UI for application that draws a histogram

dashboardPage(
  skin = "blue",
  dashboardHeader(
    title="Video Games Sales",
    
    tags$li(a(href = 'https://www.kaggle.com/',
              img(src = 'kaggle.png',
                  title = "Data Source", height = "20px"),
              style = "padding-top:14px; padding-bottom:10px;"),
            class = "dropdown"),
    
    tags$li(a(href = 'https://id.linkedin.com/in/febrianus-dwiyantoro-wibisono-3190259a',
              icon("linkedin"),
                  title = "About Author", height = "20px"),
            class = "dropdown"),
    
  
    dropdownMenu(type="message", 
                 messageItem(
                   from="Febrianus D. Wibisono", 
                   message="Enjoy the program!",
                   time=substr(Sys.time(),1,10)
                 ),
                 
                 messageItem(
                   from="Disclaimer", 
                   message="All data are obtained from third party",
                   icon=icon("exclamation-circle"),
                   time = "2018-02-26"
                 )
                 )
  ),
  
  dashboardSidebar(
    sidebarMenu(
      id="sidebar",
      menuItem("Sales History", tabName = "sales", icon=icon("laptop")),
      menuItem("Rating Performance", tabName = "rating", icon=icon("star")),
      menuItem("Search Data",tabName="search",icon=icon("search"))
    )
  ),
  
  dashboardBody(
    
    tabItems(
      tabItem("search",
              fluidRow(
                box(
                  title="Search by Publisher Name",
                  background="black",
                  width = 4,
                  selectizeInput("ïnput.sch",label="Type here:",
                                 choices=pubname,
                                 selected="Nintendo",
                                 options=list(create=TRUE)),
                  radioButtons("ïnput.arr",label="Order by:",
                               choices = c("Year","Genre","Score"),
                               inline = T,
                               selected="Year")
                  )
                
              ),
              fluidRow(
                box(
                  title="Raw Data Detail", 
                  width = 13,
                  div(tableOutput("table1"),style="font-size:80%")
                )
              )
            ),
      
      tabItem("rating",
            fluidRow(
                infoBoxOutput("topgenre"),
                infoBoxOutput("topplatform"),
                infoBoxOutput("toppublisher")
              ),
              
            fluidRow(
              box(
                  title = "Select Region of Sales",
                  background = "black",
                  width=6,
                  radioButtons("input.reg", label = "Region:",
                              choices = c("North America","Europe","Japan","Other","Global"),
                              selected = "Global",
                              inline=T)
                  ),
              
              box(
                title="Sales Performance by Genre and Score Accross Region", solidHeader=T,
                collapsible = T,
                width=12,
                plotOutput("plot2", height = 300)),
              
              box(
                title="Analysis",
                solidHeader = T,
                width=12,
                p("Global wise, sport genre gets the highest rating in average compare to other genres. It is also scored a second highest sales with USD 835.62 mio behind Action Genre with USD 1,205.65. Interesting point that User Score doesn't really allign with Critic Score as shown in bubble size. Sport only receive User Score of 7.09 in average falls in no.10 with Role-playing genre on stand strong in the top with 7.62 in average")
              )
            )
            ),
    
    tabItem("sales",
              fluidRow(
                infoBoxOutput("avgsales"),
                infoBoxOutput("toppub")
              ),
              
              fluidRow(
                box(
                  title = "Video Games Publisher",
                  background = "black",
                  width=4,
                  selectInput("input.pub", label = "Publisher Name:",
                    choices = pubname,
                    selected = "Square Enix"),
                  checkboxInput("input.tot","Show Grand Total Figure Only")
                  ),
                     
                box(
                  title="Sales History per Video Games Publisher", solidHeader=T,
                  collapsible = T,
                  width=12,
                  plotOutput("plot1", height = 300)
                  ),
                box(
                  title="Analysis",
                  solidHeader = T,
                  width=12,
                  p("Global wide sales data shows very sharp sales decline since 2008. The emerge of smartphone era with their mobile-gaming has made this phenomena. This mobile-gaming starts with casual game that tap to so-called normal gamer. In the progress, even hardcore game like Vainglory or Mobile-Legend have been introduced and received so much attention form society. This leads to shift from console game (e.g. Playstation, Wii, Xbox, etc) to mobile game which has proven to be profitable. Big Players like Nintendo, Electronic Arts, Activision and Sony Computer Entertainment suffer huge sales loss in the 5 years. Most profitable market like North America has been reduced to equal to Europe Market")
                )
                )
              )
      

    )
  )
)

