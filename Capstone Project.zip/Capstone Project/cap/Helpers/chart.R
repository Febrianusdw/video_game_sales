
library(lubridate)
library(dplyr)
library(ggplot2)
library(shinydashboard)
library(varhandle)

toppub <- vgame %>% 
  group_by(Publisher) %>% 
  tally() 

avgsales <-vgame %>%
  summarize(avgs=mean(Global_Sales))

tgenre<-vgame%>%
  group_by(Genre)%>%
  summarise(sgenre=mean(Critic_Score))%>%
  arrange(desc(sgenre))

tplatform<-vgame%>%
  group_by(Platform)%>%
  summarise(splatform=mean(Critic_Score))%>%
  arrange(desc(splatform))

tpublish<-vgame%>%
  group_by(Publisher)%>%
  summarise(spublish=mean(Critic_Score))%>%
  arrange(desc(spublish))

vna<-vgame%>%
  group_by(Genre)%>%
  summarise(cscore=mean(Critic_Score),uscore=mean(User_Score),gstotal=sum(NA_Sales))%>%
  ggplot(aes(x=cscore,y=gstotal))+
  geom_point(aes(size=uscore,col=Genre))+
  labs(subtitle="Data is collected from 1980-2017",caption="note: User Score is used as bubble size",x= "Critic Score",y="Sales (USD)")+
  guides(size=F)

veu<-vgame%>%
  group_by(Genre)%>%
  summarise(cscore=mean(Critic_Score),uscore=mean(User_Score),gstotal=sum(EU_Sales))%>%
  ggplot(aes(x=cscore,y=gstotal))+
  geom_point(aes(size=uscore,col=Genre))+
  labs(subtitle="Data is collected from 1980-2017",caption="note: User Score is used as bubble size",x= "Critic Score",y="Sales (USD)")+
  guides(size=F)

vjp<-vgame%>%
  group_by(Genre)%>%
  summarise(cscore=mean(Critic_Score),uscore=mean(User_Score),gstotal=sum(JP_Sales))%>%
  ggplot(aes(x=cscore,y=gstotal))+
  geom_point(aes(size=uscore,col=Genre))+
  labs(subtitle="Data is collected from 1980-2017",caption="note: User Score is used as bubble size",x= "Critic Score",y="Sales (USD)")+
  guides(size=F)

vot<-vgame%>%
  group_by(Genre)%>%
  summarise(cscore=mean(Critic_Score),uscore=mean(User_Score),gstotal=sum(Other_Sales))%>%
  ggplot(aes(x=cscore,y=gstotal))+
  geom_point(aes(size=uscore,col=Genre))+
  labs(subtitle="Data is collected from 1980-2017",caption="note: User Score is used as bubble size",x= "Critic Score",y="Sales (USD)")+
  guides(size=F)

vgl<-vgame%>%
  group_by(Genre)%>%
  summarise(cscore=mean(Critic_Score),uscore=mean(User_Score),gstotal=sum(Global_Sales))%>%
  ggplot(aes(x=cscore,y=gstotal))+
  geom_point(aes(size=uscore,col=Genre))+
  labs(subtitle="Data is collected from 1980-2017",caption="note: User Score is used as bubble size",x= "Critic Score",y="Sales (USD)")+
  guides(size=F)
