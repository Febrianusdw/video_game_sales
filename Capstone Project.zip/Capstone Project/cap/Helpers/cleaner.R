library(dplyr)
library(varhandle)

vgame <- read.csv("Data_input/Video_Games_Sales_as_at_22_Dec_2016.csv") %>%
  na.omit() %>%
  filter(sum(NA_Sales,EU_Sales,JP_Sales,Other_Sales) != 0 )%>%
  filter(Year_of_Release !="N/A")%>%
  mutate(
    Name=as.character(Name),
    User_Score = as.numeric(unfactor(User_Score)),
  NA_Sales=10^6*NA_Sales,
  EU_Sales=10^6*EU_Sales,
  JP_Sales=10^6*JP_Sales,
  Other_Sales=10^6*Other_Sales,
  Global_Sales=10^6*Global_Sales)


pubname <- levels(vgame$Publisher)